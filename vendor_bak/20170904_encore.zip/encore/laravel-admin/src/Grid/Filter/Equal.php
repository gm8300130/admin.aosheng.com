<?php

namespace Encore\Admin\Grid\Filter;

class Equal extends AbstractFilter
{
}
