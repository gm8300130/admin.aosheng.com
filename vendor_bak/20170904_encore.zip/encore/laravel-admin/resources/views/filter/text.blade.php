<div class="input-group">
    <div class="input-group-addon">
        <i class="fa fa-pencil"></i>
    </div>
    <input type="text" class="form-control" placeholder="{{$placeholder}}" name="{{$name}}" value="{{ request($name, $value) }}">
</div>