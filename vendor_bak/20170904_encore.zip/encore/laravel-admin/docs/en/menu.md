# Menu

Open the `http://localhost:8000/admin/auth/menu` to set left sidebar menu.

The tree menu is developed based on [Nestable] (https://github.com/dbushell/Nestable).